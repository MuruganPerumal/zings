A Pen created at CodePen.io. You can find this one at http://codepen.io/mudrenok/pen/aBWbgM.

 <p>One more wave animation to my pens)</p>
<p>Dribbble shot: https://dribbble.com/shots/3107804-wave</p>